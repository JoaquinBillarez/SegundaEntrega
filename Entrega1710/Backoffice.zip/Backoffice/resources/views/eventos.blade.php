<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <link
    href="https://getbootstrap.com/docs/5.2/assets/css/docs.css"
    rel="stylesheet"
  />
  <title>Bootstrap Example</title>
  <link rel="stylesheet" href="index.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  <header>
  <nav class="navbar navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Backoffice de AevoSport</a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="offcanvas"
        data-bs-target="#offcanvasDarkNavbar"
        aria-controls="offcanvasDarkNavbar"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div
        class="offcanvas offcanvas-end text-bg-dark"
        tabindex="-1"
        id="offcanvasDarkNavbar"
        aria-labelledby="offcanvasDarkNavbarLabel"
      >
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">
            Opciones
          </h5>
          <button
            type="button"
            class="btn-close btn-close-white"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
        <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
                <a class="nav-link" href="">Inicio</a>
              </li>
            <li class="nav-item">
              <a class="nav-link " aria-current="page" href=""
                >Ver Pagina</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/paises">Agregar Pais</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/equipos">Agregar Equipo</a>
              </li>
            <li class="nav-item">
              <a class="nav-link" href="/premium">Ver Premium</a>
            </li>
            <li class="nav-item dropdown">
              <a
                class="nav-link dropdown-toggle"
                href="#"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                Agregar Deporte
              </a>
              <ul class="dropdown-menu dropdown-menu-dark">
                <li><a class="dropdown-item" href="#">Football</a></li>
                <li><a class="dropdown-item" href="#">BascketBall</a></li>
                <li>
                  <hr class="dropdown-divider" />
                </li>
                <li><a class="dropdown-item" href="#">Agregar Evento</a></li>
              </ul>
            </li>
          </ul>
          <form class="d-flex mt-3" role="search">
            <input
              class="form-control me-2"
              type="search"
              placeholder="Buscar"
              aria-label="Search"
            />
            <button class="btn btn-success" type="submit">Buscar</button>
          </form>
        </div>
      </div>
    </div>
  </nav>
</header>
    
<div class="container-fluid px-4">
            
    <ol class="breadcrumb mb-4 mt-4">
        <li class="breadcrumb-item"><a href="index.html">Mantenedores</a></li>
        <li class="breadcrumb-item active">Productos</li>
    </ol>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i> Listado de Eventos
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12">
                    <button class="btn btn-success" type="button" onclick="abrirModal(null)">Crear Nuevo</button>
                </div>
            </div>
    
            <hr />
            <table id="tabla" class="display responsive" style="width:100%">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Descripcion</th>
                        <th>Categoria</th>
                        <th>Nro de Equipos</th>
                        <th>Estado</th>
                        <th>Editar</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
    <form action="/crearEvento" method="POST">
      @csrf
      <input type="text" name="id_Deporte" placeholder="Deporte" class="form-control mb-2">
      <input type="text" name="Fecha" placeholder="Fecha"
      class="form-control mb-2">
      <input type="text" name="Lugar" placeholder="Lugar"
      class="form-control mb-2">
      <input type="text" name="Hora" placeholder="Hora"
      class="form-control mb-2">
      <button class="btn btn-primary btn-block" type="submit">Añadir</button>
</form>

</body>
</html>