<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <link
    href="https://getbootstrap.com/docs/5.2/assets/css/docs.css"
    rel="stylesheet"
  />
  <title>Backoffice de AevoSport</title>
  <link rel="stylesheet" href="index.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
  <header>
  <nav class="navbar navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">BackOffice de AevoSport</a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="offcanvas"
        data-bs-target="#offcanvasDarkNavbar"
        aria-controls="offcanvasDarkNavbar"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div
        class="offcanvas offcanvas-end text-bg-dark"
        tabindex="-1"
        id="offcanvasDarkNavbar"
        aria-labelledby="offcanvasDarkNavbarLabel"
      >
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">
            Opciones
          </h5>
          <button
            type="button"
            class="btn-close btn-close-white"
            data-bs-dismiss="offcanvas"
            aria-label="Close"
          ></button>
        </div>
        <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link active" href="">Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#"
                >Ver Pagina</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link" href="paises">Agregar Pais</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Agregar Equipo</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="premium">Ver Premium</a>
            </li>
            <li class="nav-item dropdown">
              <a
                class="nav-link dropdown-toggle"
                href="#"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                Agregar Deporte
              </a>
              <ul class="dropdown-menu dropdown-menu-dark">
                <li><a class="dropdown-item" href="#">Football</a></li>
                <li><a class="dropdown-item" href="#">BascketBall</a></li>
                <li>
                  <hr class="dropdown-divider" />
                </li>
                <li><a class="dropdown-item" href="eventos">Agregar Evento</a></li>
              </ul>
            </li>
          </ul>
          <form class="d-flex mt-3" role="search">
            <input
              class="form-control me-2"
              type="search"
              placeholder="Buscar"
              aria-label="Search"
            />
            <button class="btn btn-success" type="submit">Buscar</button>
          </form>
        </div>
      </div>
    </div>
  </nav>
</header>
<br>
<br>
<br>

<div id="layoutSidenav_content">
  <main>
      <div class="container-fluid px-4">
          


<h1 class="mt-4">Informacion General</h1>
<ol class="breadcrumb mb-4">
<li class="breadcrumb-item active">Detalle</li>
</ol>
<div class="row">
<div class="col-4">
<div class="card bg-primary text-white mb-4">
  <div class="card-body">
      <div class="d-flex justify-content-between">
          <div>Total de Paises</div>
          <div id="total-productos">40</div>
      </div>
  </div>
  <div class="card-footer d-flex align-items-center justify-content-between">
      <a class="small text-white stretched-link" href="paises">Ver Detalles</a>
      <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> Font Awesome fontawesome.com --></div>
  </div>
</div>
</div>
<div class="col-4">
<div class="card bg-warning text-white mb-4">
  <div class="card-body">
      <div class="d-flex justify-content-between">
          <div>Total de Deportes</div>
          <div id="total-marcas">30</div>
      </div>
  </div>
  <div class="card-footer d-flex align-items-center justify-content-between">
      <a class="small text-white stretched-link" href="deportes">Ver Detalles</a>
      <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> Font Awesome fontawesome.com --></div>
  </div>
</div>
</div>
<div class="col-4">
<div class="card bg-success text-white mb-4">
  <div class="card-body">
      <div class="d-flex justify-content-between">
          <div>Total de Eventos</div>
          <div id="total-categorias">34</div>
      </div>
  </div>
  <div class="card-footer d-flex align-items-center justify-content-between">
      <a class="small text-white stretched-link" href="eventos">Ver Detalles</a>
      <div class="small text-white"><svg class="svg-inline--fa fa-angle-right fa-w-8" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" data-fa-i2svg=""><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z"></path></svg><!-- <i class="fas fa-angle-right"></i> Font Awesome fontawesome.com --></div>
  </div>
</div>
</div>
</div>

      </div>
  </main>
</div>
  


</body>

</html>