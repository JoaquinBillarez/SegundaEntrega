<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BackofficeController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/paises', function () {
    return view('paises');
});
Route::get('/deportes', function () {
    return view('deportes');
});
Route::post('/crearDeporte', [BackofficeController::class, 'CrearDeporte']);

Route::get('/eventos', function () {
    return view('eventos');
});
Route::post('/crearEvento', [BackofficeController::class, 'CrearEvento']);

Route::get('/', function () {
    return view('inicio');
});
Route::get('/premium', function () {
    return view('premium');
});


