<?php

namespace App\Http\Controllers;
use App\Models\Deporte;
use App\Models\Evento;
use App\Models\Arbitro;
use App\Models\Equipo;
use App\Models\Jugador;
use App\Models\Ligas;
use App\Models\Publicidad;
use App\Models\Resultados;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BackofficeController extends Controller
{
    public function CrearPais(Request $request){

    }
    public function CrearDeporte(Request $request){
        
        $Validator = validator::make($request->all(),[
        'Nombre' => 'required',
        'Cant_Arbitros' => 'required',
        'Cant_Jugadores' => 'required',
    ]);

    Deporte::create([
        'Nombre' => $request -> post("Nombre"),
        'Cant_Arbitros' => $request -> post("Cant_Arbitros"),
        'Cant_Jugadores' => $request -> post("Cant_Jugadores"),  

    ]);
    return back();
    }
    public function CrearEvento(Request $request){
        $Validator = validator::make($request->all(),[
            'id_Deporte' => 'required',
            'Fecha' => 'required',
            'Lugar' => 'required',
            'Hora' => 'required',
        ]);
    
        Evento::create([
            'id_Deporte' => $request -> post("id_Deporte"),
            'Fecha' => $request -> post("Fecha"),
            'Lugar' => $request -> post("Lugar"),
            'Hora' => $request -> post("Hora"), 
    
        ]);
        return back();
        
    }
}
