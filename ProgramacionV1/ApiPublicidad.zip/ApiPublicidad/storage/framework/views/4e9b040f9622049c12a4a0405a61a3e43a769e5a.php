<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">
    <link rel="shortcut icon" href="./imagenes/as.png">
    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>
</head>
<body>
    <header class="header">
        <div class="logo">
            <a href="index.html"><img src="./imagenes/as.png" alt="Logo de la marca"></a>
        </div>
        <nav>
           <ul class="nav-links">
                <li><a href="deportes.html">Deportes</a></li>
                <li><a href="subs.html">Suscribirse</a></li>
                <li><a href="cuenta.html">Cuenta</a></li>
           </ul>            
        </nav>
        <a class="btn" href="fmr.html"><button>Login</button></a>
    </header>

    <br>
    <br>
    <h1>Ultimos resultados</h1>
    <br>

    <!-- Resultados --> 

    <div class="event-container">
        <div class="resultado-uno-index">
            <div class="event-holder">
                <div class="event-title-holder">
                    <img src="./imagenes/premier.png" class="logo-liga-uno">
                    <br>
                    <a href="partido.html" class="titulo-evento"> PremierLeague<br> Fecha 4</a>
                    <p class="estado-evento">Vivo </p>
                    
                    
                </div>
                <hr>
                <div class="equipo-uno">
                    <img src="./imagenes/unitedlogo.png" class="team-logo-uno">
                    <p a href="./team-profile.html" class="team-name">ManchesterUnited</a></p>
                </div>
                <div class="puntuacion">
                
                    <p class="event-score">0 - 0</p>
                    
                    <p class="time-evento">00:00</p>
                </div>
                <div class="equipo-dos">
                    <img src="./imagenes/citylogo.png" class="team-logo-dos">
                    <p a href="./team-profile.html" class="team-name">ManchesterCity</a></p>
                </div>
            </div>
        </div>

        <div class="resultado-uno-index">
            <div class="event-holder">
                <div class="event-title-holder">
                    <img src="./imagenes/premier.png" class="logo-liga-uno">
                    <br>
                    <a href="partido.html" class="titulo-evento"> PremierLeague<br> Fecha 4</a>
                    <p class="estado-evento">Vivo</p>
                </div>
                <hr>
                <div class="equipo-uno">
                    <img src="./imagenes/unitedlogo.png" class="team-logo-uno">
                    <p a href="./team-profile.html" class="team-name">ManchesterUnited</a></p>
                </div>
                <div class="puntuacion">
                    <p class="event-score">0 - 0</p>

                    <p class="time-evento">00:00</p>
                </div>
                <div class="equipo-dos">
                    <img src="./imagenes/citylogo.png" class="team-logo-dos">
                    <p a href="./team-profile.html" class="team-name">ManchesterCity</a></p>
                </div>
            </div>
        </div>

        <div class="resultado-uno-index">
            <div class="event-holder">
                <div class="event-title-holder">
                    <img src="./imagenes/premier.png" class="logo-liga-uno">
                    <br>
                    <a href="partido.html" class="titulo-evento"> PremierLeague<br> Fecha 4</a>
                    <p class="estado-evento">Vivo</p>
                </div>
                <hr>
                <div class="equipo-uno">
                    <img src="./imagenes/unitedlogo.png" class="team-logo-uno">
                    <p a href="./team-profile.html" class="team-name">ManchesterUnited</a></p>
                </div>
                <div class="puntuacion">
                    <p class="event-score">0 - 0</p>

                    <p class="time-evento">00:00</p>
                </div>
                <div class="equipo-dos">
                    <img src="./imagenes/citylogo.png" class="team-logo-dos">
                    <p a href="./team-profile.html" class="team-name">ManchesterCity</a></p>
                </div>
            </div>
        </div>

        <div class="resultado-uno-index">
            <div class="event-holder">
                <div class="event-title-holder">
                    <img src="./imagenes/premier.png" class="logo-liga-uno">
                    <br>
                    <a href="partido.html" class="titulo-evento"> PremierLeague<br> Fecha 4</a>
                    <p class="estado-evento">Vivo</p>
                </div>
                <hr>
                <div class="equipo-uno">
                    <img src="./imagenes/unitedlogo.png" class="team-logo-uno">
                    <p a href="./team-profile.html" class="team-name">ManchesterUnited</a></p>
                </div>
                <div class="puntuacion">
                    <p class="event-score">0 - 0</p>

                    <p class="time-evento">00:00</p>
                </div>
                <div class="equipo-dos">
                    <img src="./imagenes/citylogo.png" class="team-logo-dos">
                    <p a href="./team-profile.html" class="team-name">ManchesterCity</a></p>
                </div>
            </div>
        </div>

    </div>
        <!-- Noticias --> 
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <h2>Ultimas noticias</h2>
    
    <div class="body__page">

      <div class="container__card">

          <div class="card c1">
              <div class="icon">
                <img src="./imagenes/bale.jpg" class="d-block w-100" alt="...">
              </div>
              <div class="info__description">
                  <p>Por esto acabó Bale en la MLS y no en una liga de primer nivel: “No iba a ir a Italia o España</p>
                  <input type="button" value="Leer Más">
              </div>
          </div>

          <div class="card c2">
              <div class="icon">
                <img src="./imagenes/nba.jfif" class="d-block w-100" alt="...">
              </div>
              <div class="info__description">
                  <p>NBA agencia libre 2022: últimos acuerdos, noticias, rumores y reportes alrededor de la liga
                    ¿Qué pasará con las estrellas en el mercado? Pendiente aquí para las últimas actualizaciones antes de la agencia libre.</p>
                  <input type="button" value="Leer Más">
              </div>
          </div>

          <div class="card c3">
              <div class="icon">
                <img src="./imagenes/copita.jfif" class="d-block w-100" alt="...">
              </div>
              <div class="info__description">
                  <p>Calendario y campeones del circuito ATP 2022
                    La temporada comenzó con la gira australiana y continúa, de manera cierta, hasta la gira sobre césped que desemboca en Wimbledon.</p>
                  <input type="button" value="Leer Más">
              </div>
          </div>

          

      </div>

    </div>
     
<br>
<br>
<br>
<br>
<br>
<br>
<br>
    </div>
      <div class="footer-dark">
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-3 item">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="#">Web design</a></li>
                            <li><a href="#">Development</a></li>
                            <li><a href="#">Hosting</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-md-3 item">
                        <h3>About</h3>
                        <ul>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Team</a></li>
                            <li><a href="#">Careers</a></li>
                        </ul>
                    </div>
                    <div class="col-md-6 item text">
                        <h3>Aevo</h3>
                        <p>Somos una compania que se dedica al desarollo de SoftWare, el nombre de la empresa es el conjunto de las segunda palabra de los integrantes.</p>
                    </div>
                </div>
                <p class="copyright">Aevo © 2022</p>
            </div>
        </footer>
    </div>
    <script src="js/script.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
</body>
</html><?php /**PATH C:\Users\royes\OneDrive\Escritorio\ApiPublicidad\resources\views/index.blade.php ENDPATH**/ ?>