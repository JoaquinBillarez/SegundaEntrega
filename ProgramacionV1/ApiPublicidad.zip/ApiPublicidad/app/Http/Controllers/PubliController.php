<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\QueryException;
use App\Models\PubliModel;

class PubliController extends Controller
{
    
    public function AsignarPublicidad(Request $request){
        
        $publicidades = $this -> BuscarPublicidad($request);
        return $this -> ComprobarPublicidad($publicidades);
        $this -> MostrarPublicidad();
    }
    
    private function BuscarPublicidad(Request $request){

        return $publicidades = PubliModel::all() -> where('Sponsor',$request -> Sponsor) 
        -> where('Posicion',$request -> Posicion);
    }

    private function ComprobarPublicidad($publicidades){

        if($publicidades == "[]"){
            return "No existe la publicidad";
        }
        return $publicidades;

    }
    public function MostrarPublicidad(){

        return view('imagen');

    }
}


